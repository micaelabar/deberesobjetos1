import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService
} from "./chunk-MAG246RO.js";
import "./chunk-PLL37JD2.js";
import "./chunk-LT5NPEHN.js";
import "./chunk-HSYVEA6A.js";
import "./chunk-5QBFNWJX.js";
import "./chunk-3GC3JQFY.js";
import "./chunk-JEJUSBWM.js";
import "./chunk-GNJO23XB.js";
import "./chunk-N2JJNCCI.js";
import "./chunk-J4B6MK7R.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService
};
//# sourceMappingURL=ng-zorro-antd_icon.js.map
