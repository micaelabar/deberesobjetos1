import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-NGAD4YFJ.js";
import "./chunk-N2JJNCCI.js";
import "./chunk-J4B6MK7R.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
//# sourceMappingURL=ng-zorro-antd_core_transition-patch.js.map
