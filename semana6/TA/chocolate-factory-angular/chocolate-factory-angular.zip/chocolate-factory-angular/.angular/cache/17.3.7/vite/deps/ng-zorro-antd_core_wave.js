import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-FFYTNSWL.js";
import "./chunk-4ZOV7MK4.js";
import "./chunk-RKB6EDF5.js";
import "./chunk-HSYVEA6A.js";
import "./chunk-3GC3JQFY.js";
import "./chunk-JEJUSBWM.js";
import "./chunk-GNJO23XB.js";
import "./chunk-N2JJNCCI.js";
import "./chunk-J4B6MK7R.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
//# sourceMappingURL=ng-zorro-antd_core_wave.js.map
